# Optional secure AI backend contract

The Android app is offline-first. To enable online AI answers, configure an HTTPS endpoint in **AI settings**.

The endpoint must accept:
```json
{"question":"How do I estimate concrete?","language":"English"}
```
and return:
```json
{"answer":"..."}
```

Keep your AI provider API key on the server in an environment variable. Do not put secrets in the Android app or this repository. Add authentication, rate limiting, input validation, logging controls, and an engineering safety disclaimer before public deployment. The app does not include a live AI provider integration or API credentials.
