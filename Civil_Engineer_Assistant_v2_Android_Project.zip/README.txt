CIVIL ENGINEER ASSISTANT 2.0 — ANDROID PROJECT

Included:
- English + Tamil language switch
- Offline searchable starter Q&A with bilingual answers
- Concrete volume, steel bar weight, brickwork and area conversion calculators
- Pre-concrete-pour checklist
- Optional online AI endpoint configuration (HTTPS backend contract)
- Android WebView wrapper project

BUILD APK:
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: app/build/outputs/apk/debug/app-debug.apk
6. Transfer the APK to your Android phone and install. Android may ask permission to install apps from that source.

ONLINE AI:
- The app does not include an AI provider key or ready-made hosted AI service.
- Deploy your own HTTPS backend that accepts POST JSON {question, language} and returns {answer}; see backend/README.md.
- Save that HTTPS endpoint in the app's AI settings.
- Keep API keys on the backend only. Never embed secrets in the APK.

LIMITATIONS & SAFETY:
- Offline content is a starter reference library, not a comprehensive engineering code database.
- Calculators provide preliminary quantities only.
- No DWG/Revit parsing, structural member design, reinforcement design, or MEP sizing is performed.
- Verify current applicable IS standards, revisions, project specifications, local regulations and approved drawings. Structural and life-safety decisions require qualified professional review.
